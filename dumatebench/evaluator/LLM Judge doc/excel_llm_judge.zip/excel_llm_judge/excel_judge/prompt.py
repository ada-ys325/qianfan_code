"""Prompt template for reference-free Excel LLM judging."""
from __future__ import annotations

import json
from typing import Any

RUBRIC_DIMENSIONS = [
    "instruction_coverage",
    "data_fidelity_and_internal_consistency",
    "workbook_structure_completeness",
    "formula_and_computation_integrity",
    "formatting_and_readability",
    "robustness_and_cleanliness",
]

SYSTEM_PROMPT = """你是一个严格的 Excel 办公产物 LLM-judge。你的评估必须综合 spreadsheet/Excel agent benchmark 的经验，但不要依赖 gold answer。

评估思想来源：
- SpreadsheetBench / SpreadsheetBench Verified: 只看单元格值不够，还要看结构、结果落点、图表/透视表、格式、可维护性。
- SheetCopilot / SheetAgent / SheetMind: Excel 任务覆盖 entry/manipulation、formatting、management、charts、pivot tables、formulas；执行成功和功能正确要分开看。
- WorkstreamBench: 值看起来正确但硬编码、缺少公式、缺单位标签、格式不一致，仍然是不合格的办公交付。
- G-Eval / rubric-based judge: 先按维度生成 task-specific checks，再基于证据逐条打分，输出严格 JSON。

你将收到：
1. task instruction
2. 已有 checklist
3. agent 产物目录的 Excel artifact summary

关键规则：
- checklist 是显式验收标准，优先级高于 rubric。checklist 已覆盖的要求，不得重复生成到 rubric 中。
- rubric 只评估 checklist 未覆盖、但会影响 Excel 办公交付质量的内容。
- 不要要求 gold answer；不要声称你能验证所有最终数值的绝对正确性。
- 对 correctness 类判断，只能基于 instruction、checklist、workbook summary、公式/引用/结构/样式等可观察证据，检查数据忠实性和内部一致性。
- 如果证据不足，降低 evidence_level 和置信度，不要编造结论。
- formula_and_computation_integrity 是条件适用维度：无计算需求，或 checklist 已覆盖公式/计算检查时，标记 not_applicable，不计入总分。
- 如果某维度不适用，normalized_weight 必须为 0；总分只对 applicable=true 的维度重新归一化。
- 输出必须是严格 JSON 对象，不要 markdown 围栏，不要解释性前后缀。

Rubric dimensions:
1. instruction_coverage: checklist 未覆盖的 instruction 覆盖、交付对象、约束和使用场景适配问题。
2. data_fidelity_and_internal_consistency: checklist 未覆盖的数据忠实性和内部一致性问题，例如单位/口径冲突、表格与图表结论不一致、无依据业务结论、关键字段语义不一致。
3. workbook_structure_completeness: checklist 未覆盖的 workbook 结构质量，例如 sheet 组织、区域布局、图表/透视表与表格关系。
4. formula_and_computation_integrity: checklist 未覆盖且任务需要计算时，评估公式/计算逻辑是否可审计、范围是否合理、是否用硬编码替代应有公式。
5. formatting_and_readability: checklist 未覆盖的视觉层级、数字格式一致性、图表可读性、冻结/筛选等办公可读性。
6. robustness_and_cleanliness: checklist 未覆盖的文件可打开性、损坏/多余文件、命名混乱、隐藏异常内容、可复用性。

Output JSON schema:
{
  "checklist_deduplication": {
    "covered_by_checklist": [{"checklist_item": "...", "covered_requirement": "..."}],
    "excluded_from_rubric": [{"candidate_check": "...", "reason": "already covered by checklist item ..."}]
  },
  "task_rubrics": [
    {
      "dimension": "instruction_coverage|data_fidelity_and_internal_consistency|workbook_structure_completeness|formula_and_computation_integrity|formatting_and_readability|robustness_and_cleanliness",
      "applicable": true,
      "applicability_reason": "...",
      "weight": 0.0,
      "normalized_weight": 0.0,
      "checks": [{"id": "...", "criterion": "...", "not_covered_by_checklist_reason": "..."}]
    }
  ],
  "check_results": [
    {"check_id": "...", "status": "pass|partial|fail|not_applicable", "evidence": "...", "reason": "..."}
  ],
  "dimension_scores": {
    "instruction_coverage": {"applicable": true, "score": 0.0, "evidence_level": "strong|medium|weak", "reason": "..."}
  },
  "overall_score": 0.0,
  "verdict": "pass|borderline|fail",
  "failure_modes": ["..."],
  "recommendations": ["..."]
}

Scoring:
- score 使用 0 到 1 的小数。
- verdict: overall_score >= 0.8 为 pass，0.6 到 0.8 为 borderline，低于 0.6 为 fail；如果存在文件无法打开等关键失败，可降为 fail。
- evidence_level: strong 表示有明确 workbook/公式/结构证据；medium 表示有部分证据但不能完全验证；weak 表示主要依赖 instruction 和表面内容。
"""


def build_user_prompt(instruction: str, checklist: str, artifact_summary: dict[str, Any]) -> str:
    payload = {
        "task_instruction": instruction.strip(),
        "existing_checklist": checklist.strip() or "(empty checklist)",
        "artifact_summary": artifact_summary,
        "judge_request": (
            "Generate task-specific rubrics that do not duplicate checklist items, then evaluate "
            "the Excel artifact evidence against those rubrics. Return strict JSON only."
        ),
    }
    return json.dumps(payload, ensure_ascii=False, indent=2)


def build_dry_run_result() -> dict[str, Any]:
    """Return a deterministic placeholder for dry-run report generation."""
    return {
        "checklist_deduplication": {
            "covered_by_checklist": [],
            "excluded_from_rubric": [],
        },
        "task_rubrics": [
            {
                "dimension": dim,
                "applicable": dim != "formula_and_computation_integrity",
                "applicability_reason": "dry-run placeholder; real applicability is judged by the LLM",
                "weight": 1.0 / len(RUBRIC_DIMENSIONS),
                "normalized_weight": 0.2 if dim != "formula_and_computation_integrity" else 0.0,
                "checks": [],
            }
            for dim in RUBRIC_DIMENSIONS
        ],
        "check_results": [],
        "dimension_scores": {
            dim: {
                "applicable": dim != "formula_and_computation_integrity",
                "score": None,
                "evidence_level": "weak",
                "reason": "dry-run did not call LLM judge",
            }
            for dim in RUBRIC_DIMENSIONS
        },
        "overall_score": None,
        "verdict": "dry_run",
        "failure_modes": [],
        "recommendations": ["Run without --dry-run to call the configured OpenAI-compatible judge."],
    }
