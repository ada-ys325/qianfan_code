# Evaluator Protocol

## Rubric generation

1. 只读取当前 `--task-dir/evaluator/checks.yaml`。摘要包含 check id、description、type、目标文件和关键词。
2. rubric 不重复文件存在、文件格式、关键词/章节标题等已覆盖机械检查。
3. 每个 criterion 必须原子化、候选无关，并声明可定位的 `evidence_type`。
4. 音视频 criterion 可使用 `audio`、`video` 或 `multimodal` modality，重点观察内容正确性、语音/音乐/环境声可懂度、音画同步、剪辑连续性、技术质量和实质要求完成度。
5. 依赖缺失的参考答案、原视频、transcript 或事实 golden 时，设置 `needs_human_golden_review=true`，并填写 `golden_source` 或使用 `evidence_type=human_review`。不要删除同 rubric 中仍可执行的 criterion。

## Judge behavior

- 文本和结构化 artifact 以 inventory/excerpt 发送；媒体绝不进入 excerpt。
- 音频 `data_url` 模式使用 `input_audio` base64 + format；默认视频模式使用 ffmpeg/ffprobe 均匀抽帧，并发送 GPT-4o 支持的 `image_url` data parts。
- `video_url` 不是 GPT-4o Chat Completions 的标准输入。只有 provider 明确支持时才设置 `DU_MATE_VIDEO_MODE=video_url`；URL 模式还需配置 `DU_MATE_MEDIA_BASE_URL`。
- 抽帧表示不能可靠评价音频、音画同步或完整运动连续性，这类 criterion 缺少其他媒体依据时必须 `cannot_assess`。
- 媒体打开后再次执行 `fstat` 和有界读取，避免采集与请求之间文件变化绕过大小限制。
- 模型 judgment 必须包含 rubric criterion id、`assessed|cannot_assess` 状态、0..4 有限分数或 null、list evidence 和 0..1 confidence；未知/重复 id 或越界分数会失败。
- `needs_human_golden_review` criterion 强制为 `cannot_assess`。不可传输视频只影响 `video`/`multimodal` criteria，不阻塞可独立执行的文本 criterion。
- `judge_score_conservative` 把不可评分权重计为 0；`judge_score_assessed_only` 只在已评分权重内归一化；`assessment_coverage` 单独报告覆盖率。

## Provider compatibility

OpenAI-compatible Chat Completions 并未统一所有视频和 URL 音频字段。默认 payload 是规范化基线，而不是对每个 provider 的兼容承诺。HTTP 4xx 会抛出 `MediaTransportError`，提示检查 provider 支持或切换 `DU_MATE_MEDIA_MODE=url`；不会转换成通过结果。

标准 `input_audio` data payload 仅直接支持 MP3/WAV。M4A/FLAC/AAC/OGG 会被正确识别和审计，但 data 模式会要求使用 URL/provider adapter，不会把二进制当文本或静默忽略。
