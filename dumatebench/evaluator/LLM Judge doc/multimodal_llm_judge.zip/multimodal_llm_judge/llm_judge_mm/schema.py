from __future__ import annotations

import hashlib
import json
import math
from typing import Any

SCHEMA_VERSION = "1.1"
SUPPORTED_SCHEMA_VERSIONS = {"1.0", "1.1"}
SCORE_LEVELS = (0, 1, 2, 3, 4)
DIMENSIONS = {
    "content_relevance": "内容紧扣任务目标与读者。",
    "factual_correctness_faithfulness": "事实、数字和引文有可定位依据。",
    "requirement_completeness": "覆盖任务的实质要求和交付约束。",
    "structure_coherence": "结构、顺序和叙述连贯。",
    "technical_quality": "媒体或文件的技术质量满足任务要求。",
    "audio_visual_quality": "语音、音乐、环境声、音画同步和剪辑质量可接受。",
}


class SchemaError(ValueError):
    pass


def stable_hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _text(value: Any, field: str) -> str:
    value = str(value or "").strip()
    if not value:
        raise SchemaError(f"{field} must be non-empty")
    return value


def _criterion(raw: dict[str, Any], index: int) -> dict[str, Any]:
    cid = _text(raw.get("id") or f"criterion_{index}", "criterion.id")
    dimension = _text(raw.get("dimension"), f"{cid}.dimension")
    if dimension not in DIMENSIONS:
        raise SchemaError(f"{cid}.dimension is unsupported: {dimension}")
    try:
        weight = float(raw.get("weight", 0))
    except (TypeError, ValueError) as exc:
        raise SchemaError(f"{cid}.weight must be numeric") from exc
    if weight <= 0:
        raise SchemaError(f"{cid}.weight must be positive")
    levels_raw = raw.get("levels")
    if not isinstance(levels_raw, dict):
        raise SchemaError(f"{cid}.levels must be an object")
    levels = {str(score): _text(levels_raw.get(str(score), levels_raw.get(score)), f"{cid}.levels.{score}") for score in SCORE_LEVELS}
    modality = raw.get("modality", "text")
    if modality not in {"text", "audio", "video", "multimodal", "structured"}:
        raise SchemaError(f"{cid}.modality is unsupported: {modality}")
    needs = raw.get("needs_human_golden_review", False)
    if not isinstance(needs, bool):
        raise SchemaError(f"{cid}.needs_human_golden_review must be boolean")
    golden = raw.get("golden_source")
    if golden is not None and not isinstance(golden, str):
        raise SchemaError(f"{cid}.golden_source must be a string or null")
    evidence = raw.get("evidence_type", "artifact_quote" if modality == "text" else "media_timestamp")
    if evidence not in {"artifact_quote", "media_timestamp", "structural", "metadata", "reference_comparison", "human_review"}:
        raise SchemaError(f"{cid}.evidence_type is unsupported: {evidence}")
    if needs and not (golden or evidence == "human_review"):
        raise SchemaError(f"{cid} needs human golden review but has no golden_source or human_review evidence_type")
    return {
        "id": cid, "dimension": dimension, "description": _text(raw.get("description"), f"{cid}.description"),
        "weight": weight, "critical": bool(raw.get("critical", False)),
        "evidence_required": bool(raw.get("evidence_required", True)), "levels": levels,
        "modality": modality, "needs_human_golden_review": needs,
        "golden_source": golden, "evidence_type": evidence,
    }


def normalize_rubric(raw: dict[str, Any], *, task_id: str, instruction_hash: str, min_criteria: int = 3) -> dict[str, Any]:
    values = raw.get("criteria")
    if not isinstance(values, list) or not values:
        raise SchemaError("rubric.criteria must be a non-empty list")
    if not min_criteria <= len(values) <= 16:
        raise SchemaError(f"rubric.criteria must contain {min_criteria} to 16 criteria")
    criteria = [_criterion(item, i) for i, item in enumerate(values, 1) if isinstance(item, dict)]
    if len(criteria) != len(values):
        raise SchemaError("every rubric criterion must be an object")
    if len({item["id"] for item in criteria}) != len(criteria):
        raise SchemaError("rubric criterion ids must be unique")
    total = sum(item["weight"] for item in criteria)
    if total <= 0:
        raise SchemaError("rubric weights must sum to a positive number")
    for item in criteria:
        item["weight"] = round(item["weight"] / total, 8)
    rubric = {
        "schema_version": SCHEMA_VERSION, "task_id": task_id,
        "instruction_hash": instruction_hash,
        "dimensions": list(dict.fromkeys(item["dimension"] for item in criteria)),
        "criteria": criteria,
    }
    rubric["rubric_hash"] = stable_hash(rubric)
    return rubric


def validate_rubric(raw: dict[str, Any], *, instruction_hash: str | None = None) -> dict[str, Any]:
    if raw.get("schema_version") not in SUPPORTED_SCHEMA_VERSIONS:
        raise SchemaError(f"unsupported rubric schema_version: {raw.get('schema_version')}")
    if instruction_hash and raw.get("instruction_hash") != instruction_hash:
        raise SchemaError("rubric instruction_hash does not match instruction")
    return normalize_rubric(raw, task_id=_text(raw.get("task_id"), "rubric.task_id"), instruction_hash=_text(raw.get("instruction_hash"), "rubric.instruction_hash"), min_criteria=1)


def normalize_judgment(raw: dict[str, Any], rubric: dict[str, Any]) -> dict[str, Any]:
    values = raw.get("criteria")
    if not isinstance(values, list):
        raise SchemaError("judgment.criteria must be a list")
    rubric_ids = {item["id"] for item in rubric["criteria"]}
    seen: set[str] = set()
    criteria = []
    for raw_item in values:
        if not isinstance(raw_item, dict):
            raise SchemaError("every judgment criterion must be an object")
        cid = _text(raw_item.get("id"), "judgment criterion id")
        if cid not in rubric_ids:
            raise SchemaError(f"judgment contains unknown criterion: {cid}")
        if cid in seen:
            raise SchemaError(f"judgment contains duplicate criterion: {cid}")
        seen.add(cid)
        status = raw_item.get("status")
        if status not in {"assessed", "cannot_assess"}:
            raise SchemaError(f"{cid}.status must be assessed or cannot_assess")
        score = raw_item.get("score")
        if status == "assessed":
            if isinstance(score, bool) or not isinstance(score, (int, float)) or not math.isfinite(float(score)) or not 0 <= float(score) <= 4:
                raise SchemaError(f"{cid}.score must be a finite number between 0 and 4")
            score = float(score)
        elif score is not None:
            raise SchemaError(f"{cid}.score must be null when status is cannot_assess")
        evidence = raw_item.get("evidence", [])
        if not isinstance(evidence, list):
            raise SchemaError(f"{cid}.evidence must be a list")
        confidence = raw_item.get("confidence", 0.0)
        if isinstance(confidence, bool) or not isinstance(confidence, (int, float)) or not math.isfinite(float(confidence)) or not 0 <= float(confidence) <= 1:
            raise SchemaError(f"{cid}.confidence must be between 0 and 1")
        criteria.append({"id": cid, "status": status, "score": score, "evidence": evidence,
                         "rationale": str(raw_item.get("rationale", "")), "confidence": float(confidence)})
    for cid in rubric_ids - seen:
        criteria.append({"id": cid, "status": "cannot_assess", "score": None, "evidence": [],
                         "rationale": "模型未返回该 criterion。", "confidence": 0.0})
    return {"criteria": criteria, "summary": str(raw.get("summary", ""))}


def _force_cannot_assess_ids(judgment: dict[str, Any], ids: set[str], reason: str) -> dict[str, Any]:
    output = dict(judgment)
    criteria = []
    for item in judgment["criteria"]:
        item = dict(item)
        if item["id"] in ids:
            item.update({"status": "cannot_assess", "score": None, "evidence": [],
                         "rationale": reason, "confidence": 0.0})
        criteria.append(item)
    output["criteria"] = criteria
    return output


def force_cannot_assess(judgment: dict[str, Any], rubric: dict[str, Any]) -> dict[str, Any]:
    ids = {item["id"] for item in rubric["criteria"] if item["needs_human_golden_review"]}
    return _force_cannot_assess_ids(
        judgment, ids,
        "缺少可靠 golden/reference，按 rubric 标记为 needs_human_golden_review，不能猜测评分。",
    )


def force_media_unavailable(judgment: dict[str, Any], rubric: dict[str, Any], categories: set[str]) -> dict[str, Any]:
    ids = {item["id"] for item in rubric["criteria"]
           if item["modality"] == "multimodal" or item["modality"] in categories}
    return _force_cannot_assess_ids(judgment, ids, "所需媒体附件不可传输，不能听看或可靠判定。")
