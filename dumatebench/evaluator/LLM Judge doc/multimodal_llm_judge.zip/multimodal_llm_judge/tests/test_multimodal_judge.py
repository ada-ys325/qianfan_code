from __future__ import annotations

import base64
import io
import tempfile
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import patch
from typing import Any

from llm_judge_mm.artifacts import MediaConfig, artifact_inventory, collect_artifacts, extract_artifact
from llm_judge_mm.checks import filter_duplicate_criteria
from llm_judge_mm.llm import LLMClient, MediaTransportError, _extract_video_frames, build_multimodal_messages
from llm_judge_mm.runner import JudgeRunner, load_task_inputs
from llm_judge_mm.schema import force_cannot_assess, normalize_rubric, stable_hash


LEVELS = {str(i): f"level {i}" for i in range(5)}


def criterion(cid: str, description: str, *, modality: str = "text", needs: bool = False) -> dict[str, Any]:
    return {"id": cid, "dimension": "content_relevance", "description": description, "weight": 1,
            "levels": LEVELS, "modality": modality, "needs_human_golden_review": needs,
            "golden_source": "human review required" if needs else None,
            "evidence_type": "human_review" if needs else "artifact_quote"}


class FakeClient:
    def __init__(self, response: dict[str, Any] | None = None) -> None:
        self.messages: list[list[dict[str, Any]]] = []
        self.response = response or {"criteria": [], "summary": "ok"}

    def complete_json(self, messages: list[dict[str, Any]]) -> dict[str, Any]:
        self.messages.append(messages)
        return self.response


class ArtifactTests(unittest.TestCase):
    def test_media_is_metadata_only_and_text_inventory_has_excerpt(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "bad.mp3").write_bytes(b"not audio but never decoded as text")
            (root / "note.md").write_text("hello", encoding="utf-8")
            (root / "data.json").write_text('{"answer": 42}', encoding="utf-8")
            (root / "rubric.generated.json").write_text("{}", encoding="utf-8")
            items = collect_artifacts(root, media_config=MediaConfig(max_bytes=100))
            media = next(item for item in items if item["category"] == "audio")
            self.assertIsNone(media["content"])
            self.assertEqual(media["mime_type"], "audio/mpeg")
            inventory = artifact_inventory(items)
            self.assertNotIn("excerpt", next(item for item in inventory if item["category"] == "audio"))
            self.assertEqual(next(item for item in inventory if item["path"] == "note.md")["excerpt"], "hello")
            self.assertEqual(next(item for item in inventory if item["path"] == "data.json")["structure"]["top_level_keys"], ["answer"])
            self.assertNotIn("rubric.generated.json", {item["path"] for item in inventory})

    def test_size_limit_is_explicit(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "clip.mp4"
            path.write_bytes(b"0123456789")
            item = extract_artifact(path, root=root, media_config=MediaConfig(max_bytes=3))
            self.assertEqual(item["transport"]["status"], "cannot_assess")
            self.assertIn("exceeds", item["transport"]["reason"])


class PayloadTests(unittest.TestCase):
    def test_audio_and_video_parts_are_gpt4o_compatible(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "a.mp3").write_bytes(b"audio")
            (root / "v.mp4").write_bytes(b"video")
            items = collect_artifacts(root, media_config=MediaConfig(max_bytes=100))
            with patch("llm_judge_mm.llm._extract_video_frames", return_value=[(1.25, b"jpeg")]):
                messages = build_multimodal_messages(
                    text="judge", artifacts=items, media_config=MediaConfig(max_bytes=100))
            parts = messages[0]["content"]
            types = {part["type"] for part in parts if "type" in part}
            self.assertEqual(types, {"text", "input_audio", "image_url"})
            self.assertNotIn("video_url", types)
            audio = next(part for part in parts if part["type"] == "input_audio")
            self.assertEqual(base64.b64decode(audio["input_audio"]["data"]), b"audio")
            image = next(part for part in parts if part["type"] == "image_url")
            self.assertEqual(base64.b64decode(image["image_url"]["url"].split(",", 1)[1]), b"jpeg")
            self.assertIn("1.250s", repr(messages))
            self.assertNotIn(str(root), repr(messages))

    def test_video_url_requires_explicit_opt_in(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "v.mp4").write_bytes(b"video")
            config = MediaConfig(max_bytes=100, video_mode="video_url")
            item = extract_artifact(root / "v.mp4", root=root, media_config=config)
            messages = build_multimodal_messages(text="judge", artifacts=[item], media_config=config)
            types = {part["type"] for part in messages[0]["content"]}
            self.assertIn("video_url", types)

    def test_missing_frame_extractor_has_clear_error(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "v.mp4"
            path.write_bytes(b"video")
            with patch("llm_judge_mm.llm.subprocess.run", side_effect=FileNotFoundError):
                with self.assertRaisesRegex(MediaTransportError, "DU_MATE_FFMPEG_PATH"):
                    _extract_video_frames(path, "v.mp4", MediaConfig(max_bytes=100))

    def test_unsupported_audio_format_has_clear_error(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "a.flac"
            path.write_bytes(b"audio")
            item = extract_artifact(path, root=root, media_config=MediaConfig(max_bytes=100))
            with self.assertRaisesRegex(MediaTransportError, "URL mode"):
                build_multimodal_messages(text="judge", artifacts=[item], media_config=MediaConfig(max_bytes=100))

    def test_multimodal_http_400_raises_instead_of_scoring_zero(self) -> None:
        client = LLMClient(model="gpt-4o", base_url="https://provider.invalid/v1", retries=0)
        error = urllib.error.HTTPError(
            "https://provider.invalid/v1/chat/completions", 400, "bad request", {}, io.BytesIO(b"{}"))
        messages = [{"role": "user", "content": [
            {"type": "text", "text": "judge"},
            {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,anBlZw=="}},
        ]}]
        with patch("llm_judge_mm.llm.urllib.request.urlopen", side_effect=error):
            with self.assertRaisesRegex(MediaTransportError, "HTTP 400"):
                client.complete_json(messages)

    def test_text_only_message_remains_string_content(self) -> None:
        from llm_judge_mm.prompts import judge_messages
        messages = judge_messages(instruction="x", rubric={}, artifacts=[], references=[])
        self.assertIsInstance(messages[1]["content"], str)


class RubricTests(unittest.TestCase):
    def test_checks_remove_only_mechanical_duplicates(self) -> None:
        checks = [{"id": "exists", "type": "evaluate_file_exist", "description": "file exists", "args": {"file": "x.mp4"}},
                  {"id": "format", "type": "evaluate_file_format_valid", "description": "format", "args": {"file": "x.mp4"}}]
        values = [criterion("a", "交付文件必须存在"), criterion("b", "内容与任务要求一致"), criterion("c", "媒体技术质量良好", modality="video")]
        filtered = filter_duplicate_criteria(values, checks)
        self.assertEqual([item["id"] for item in filtered], ["b", "c"])

    def test_human_golden_marker_forces_cannot_assess(self) -> None:
        rubric = normalize_rubric({"criteria": [criterion("a", "事实正确", needs=True), criterion("b", "相关",), criterion("c", "完整")],
            }, task_id="t", instruction_hash="h")
        judgment = {"criteria": [{"id": "a", "status": "assessed", "score": 4, "evidence": ["guess"], "confidence": 1},
                                  {"id": "b", "status": "assessed", "score": 3, "evidence": [], "confidence": 1}], "summary": "x"}
        result = force_cannot_assess(judgment, rubric)
        self.assertEqual(result["criteria"][0]["status"], "cannot_assess")
        self.assertIsNone(result["criteria"][0]["score"])
        self.assertEqual(result["criteria"][1]["score"], 3)


class RunnerTests(unittest.TestCase):
    def test_temporary_session_runs_mp3_and_mp4_payload(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            task = Path(directory)
            (task / "instruction.md").write_text("评估音视频", encoding="utf-8")
            outputs = task / "run_outputs"
            outputs.mkdir()
            (outputs / "voice.mp3").write_bytes(b"audio")
            (outputs / "ad.mp4").write_bytes(b"video")
            config = MediaConfig(max_bytes=100)
            inputs = load_task_inputs(task, media_config=config)
            rubric = normalize_rubric({"criteria": [criterion("a", "声音", modality="audio"),
                criterion("b", "视频", modality="video"), criterion("c", "整体", modality="multimodal")]},
                task_id="t", instruction_hash=stable_hash(inputs["instruction"]))
            response = {"criteria": [{"id": cid, "status": "assessed", "score": 3, "evidence": [], "confidence": 1.0}
                                     for cid in ("a", "b", "c")], "summary": "ok"}
            client = FakeClient(response)
            with patch("llm_judge_mm.llm._extract_video_frames", return_value=[(0.5, b"jpeg")]):
                result = JudgeRunner(client, media_config=config).evaluate(
                    instruction=inputs["instruction"], rubric=rubric, artifacts=inputs["artifacts"])
            parts = client.messages[0][1]["content"]
            self.assertIn("input_audio", {part["type"] for part in parts})
            self.assertIn("image_url", {part["type"] for part in parts})
            self.assertNotIn("video_url", {part["type"] for part in parts})
            self.assertEqual(len(result["attachments"]), 2)
            self.assertNotIn("base64", repr(result["attachments"]))

    def test_generate_rubric_uses_current_session_checks(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            task = Path(directory)
            evaluator = task / "evaluator"
            evaluator.mkdir()
            checks_path = evaluator / "checks.yaml"
            checks_path.write_text(
                "checks:\n  - id: file_exists\n    description: 成片文件存在\n"
                "    type: evaluate_file_exist\n    args: {file: run_outputs/ad.mp4}\n",
                encoding="utf-8",
            )
            raw = {"criteria": [criterion("exists", "交付文件必须存在"), criterion("content", "广告内容正确"),
                                criterion("quality", "音画技术质量", modality="multimodal"),
                                criterion("sync", "音画同步", modality="video")]}
            client = FakeClient(raw)
            rubric = JudgeRunner(client, media_config=MediaConfig()).generate_rubric(
                task_id="session-a", instruction="制作广告", checks_path=checks_path)
            self.assertEqual([item["id"] for item in rubric["criteria"]], ["content", "quality", "sync"])
            self.assertIn("file_exists", client.messages[0][1]["content"])

    def test_media_is_read_once_for_repeated_judge_runs(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "clip.mp4").write_bytes(b"video")
            artifact = extract_artifact(root / "clip.mp4", root=root, media_config=MediaConfig(max_bytes=100))
            rubric = normalize_rubric({"criteria": [criterion("a", "a"), criterion("b", "b"), criterion("c", "c")]},
                task_id="t", instruction_hash=stable_hash("instruction"))
            response = {"criteria": [{"id": cid, "status": "assessed", "score": 3, "evidence": [], "confidence": 1.0}
                                     for cid in ("a", "b", "c")], "summary": "ok"}
            client = FakeClient(response)
            runner = JudgeRunner(client, media_config=MediaConfig(max_bytes=100))
            with patch("llm_judge_mm.llm._extract_video_frames", return_value=[(0.5, b"jpeg")]) as extract:
                result = runner.evaluate(instruction="instruction", rubric=rubric, artifacts=[artifact], judge_runs=2)
            self.assertEqual(extract.call_count, 1)
            self.assertEqual(len(client.messages), 2)
            self.assertNotIn("base64", repr(result["attachments"]))

    def test_media_unavailable_preserves_text_criteria(self) -> None:
        response = {"criteria": [{"id": cid, "status": "assessed", "score": 3, "evidence": [], "confidence": 1.0}
                                 for cid in ("a", "b", "c")], "summary": "ok"}
        client = FakeClient(response)
        runner = JudgeRunner(client, media_config=MediaConfig(max_bytes=1))
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "clip.mp4").write_bytes(b"too large")
            artifact = extract_artifact(root / "clip.mp4", root=root, media_config=MediaConfig(max_bytes=1))
            rubric = normalize_rubric({"criteria": [criterion("a", "a", modality="video"),
                criterion("b", "b"), criterion("c", "c")]}, task_id="t", instruction_hash=stable_hash("instruction"))
            result = runner.evaluate(instruction="instruction", rubric=rubric, artifacts=[artifact])
            self.assertAlmostEqual(result["assessment_coverage"], 2 / 3, places=4)
            self.assertEqual(len(client.messages), 1)
            self.assertEqual(result["attachments"][0]["transport_status"], "cannot_assess")
            self.assertEqual(result["criteria"][0]["status"], "cannot_assess")


if __name__ == "__main__":
    unittest.main()
