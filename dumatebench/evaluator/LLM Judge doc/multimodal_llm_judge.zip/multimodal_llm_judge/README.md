# Multimodal LLM Judge Extension

这是一个与 `DataAnnotation` 原代码隔离的 MP3/MP4 judge 实现，位于 `benchmark/multimodal_llm_judge`。它读取现有 task/session 作为输入，但不会修改原 task、`checks.yaml` 或历史产物。

## 支持范围

- 音频：`.mp3`、`.wav`、`.m4a`、`.flac`、`.aac`、`.ogg`
- 视频：`.mp4`、`.mov`、`.webm`、`.mkv`
- 文本/结构化 inventory：`.txt`、`.md`、`.json`、`.docx`、`.html`、`.yaml`、`.yml`

媒体在采集阶段只记录 path、MIME、大小、类别和传输状态，不进入文本 excerpt。judge 构造请求时才读取媒体，并且每个媒体附件只读取一次。审计结果只记录附件摘要，不记录 base64。

## 配置

```bash
export OPENAI_BASE_URL="https://your-provider.example/v1"
read -s OPENAI_API_KEY
export OPENAI_API_KEY
export DU_MATE_MEDIA_MODE=data_url       # data_url | url | disabled
export DU_MATE_MEDIA_MAX_BYTES=20971520
export DU_MATE_VIDEO_MODE=frames         # frames (GPT-4o) | video_url (provider opt-in)
export DU_MATE_VIDEO_FRAME_COUNT=8
export DU_MATE_FFMPEG_PATH=ffmpeg
export DU_MATE_FFPROBE_PATH=ffprobe
# URL mode only:
export DU_MATE_MEDIA_BASE_URL=https://media.example.invalid/task
```

不要把 API key 写入源码、README 或命令参数。`LLMClient` 自动读取 `OPENAI_BASE_URL` 和 `OPENAI_API_KEY`；base URL 也可通过 `--base-url` 覆盖。默认 `frames` 模式使用 ffmpeg/ffprobe 均匀抽取 JPEG 帧，并作为 GPT-4o Chat Completions 支持的 `image_url` data parts 发送，不构造 `video_url`。只有确认 provider 支持视频直传时才显式设置 `DU_MATE_VIDEO_MODE=video_url`。音频 data 模式仍使用 `input_audio` base64 + `format`，需要模型/provider 支持音频输入。provider 返回多模态 4xx 时客户端会给出明确配置错误，不会静默通过或折算为 0 分。超过大小限制或 `disabled` 时，对应 criterion 为 `cannot_assess`。

## 运行

```bash
PYTHONPATH=/mnt/cfs_algo_bj/workspace/sijinhua/benchmark/multimodal_llm_judge \
python -m llm_judge_mm.cli generate-rubric \
  --task-dir /path/to/task-session \
  --reference-dir /path/to/reference \
  --rubric-out /tmp/rubric.json

PYTHONPATH=/mnt/cfs_algo_bj/workspace/sijinhua/benchmark/multimodal_llm_judge \
python -m llm_judge_mm.cli judge \
  --task-dir /path/to/task-session \
  --reference-dir /path/to/reference \
  --rubric /tmp/rubric.json \
  --result-out /tmp/judge.json
```

生成 rubric 时只读取当前 task session 的 `evaluator/checks.yaml`，提取 check 描述、目标文件和关键词；仅过滤明确重复的机械存在、格式、关键词检查，不按任务 ID 跨 session 去重。

criterion 可声明 `modality`、`needs_human_golden_review`、`golden_source`、`evidence_type`。没有可靠 transcript、参考答案、原视频或事实 golden 时必须使用 `needs_human_golden_review: true`；judge 会强制输出 `cannot_assess` 和 `score: null`，不会猜测分数，同时保留其他可执行 criterion。

## 诊断

- 附件 inventory 中 `transport_status=ready` 才会进入多模态 payload。
- `cannot_assess` 且 `attachments` 中有 `cannot_assess` 状态：检查大小限制、媒体路径和 `DU_MATE_MEDIA_MODE`。
- provider rejection：确认 provider 支持 `input_audio`/`video_url`，否则切换 `url` 或接入 provider-specific adapter。
- 旧的纯文本 rubric（schema 1.0）仍可验证；新生成 rubric 使用 schema 1.1。

运行测试：

```bash
cd /mnt/cfs_algo_bj/workspace/sijinhua/benchmark/multimodal_llm_judge
python -m unittest discover -s tests -v
```
