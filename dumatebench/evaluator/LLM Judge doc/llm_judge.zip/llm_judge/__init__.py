"""Rubric-based LLM judge for DuMateBench textual artifacts."""

from .runner import JudgeRunner

__all__ = ["JudgeRunner"]

