from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from annotation_pipeline.evaluator_smoke import parse_json_stdout
from annotation_pipeline.llm import LLMClient

from .runner import JudgeRunner, load_task_inputs, read_json, write_json


def _common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--task-dir", required=True)
    parser.add_argument("--outputs-dir", default=None, help="Defaults to <task-dir>/run_outputs")
    parser.add_argument("--reference-dir", default=None, help="Defaults to <task-dir>/workspace_seed; use '-' to disable")
    parser.add_argument("--model", default="gpt-4o-mini")
    parser.add_argument("--base-url", default=None)
    parser.add_argument("--api-key-env", default="OPENAI_API_KEY")
    parser.add_argument("--max-files", type=int, default=20)
    parser.add_argument("--total-chars", type=int, default=60000)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Rubric-based LLM judge for DuMateBench textual artifacts")
    sub = parser.add_subparsers(dest="command", required=True)

    generate = sub.add_parser("generate-rubric", help="Generate and lock a task-specific rubric")
    _common(generate)
    generate.add_argument("--rubric-out", required=True)

    evaluate = sub.add_parser("evaluate", help="Evaluate outputs using an existing locked rubric")
    _common(evaluate)
    evaluate.add_argument("--rubric", required=True)
    evaluate.add_argument("--result-out", required=True)
    evaluate.add_argument("--rule-result", default=None)
    evaluate.add_argument("--run-rule-evaluator", action="store_true")
    evaluate.add_argument("--judge-runs", type=int, default=1)
    evaluate.add_argument("--rule-weight", type=float, default=0.4)

    run = sub.add_parser("run", help="Generate a locked rubric and evaluate in one command")
    _common(run)
    run.add_argument("--rubric-out", required=True)
    run.add_argument("--result-out", required=True)
    run.add_argument("--rule-result", default=None)
    run.add_argument("--run-rule-evaluator", action="store_true")
    run.add_argument("--judge-runs", type=int, default=1)
    run.add_argument("--rule-weight", type=float, default=0.4)
    return parser.parse_args(argv)


def _paths(args: argparse.Namespace) -> tuple[Path, Path, Path | None]:
    task_dir = Path(args.task_dir).expanduser().resolve()
    outputs = Path(args.outputs_dir).expanduser().resolve() if args.outputs_dir else task_dir / "run_outputs"
    if args.reference_dir == "-":
        references = None
    elif args.reference_dir:
        references = Path(args.reference_dir).expanduser().resolve()
    else:
        references = task_dir / "workspace_seed"
    return task_dir, outputs, references


def _rule_result(args: argparse.Namespace, task_dir: Path) -> dict[str, Any] | None:
    if getattr(args, "run_rule_evaluator", False):
        evaluator = task_dir / "evaluator" / "evaluator.py"
        env = dict(os.environ)
        proc = subprocess.run(
            [sys.executable, str(evaluator), "--task-dir", str(task_dir)],
            text=True,
            capture_output=True,
            check=False,
            env=env,
        )
        parsed = parse_json_stdout(proc.stdout)
        if parsed is None:
            raise RuntimeError(f"rule evaluator did not return JSON: {proc.stderr[-800:]}")
        return parsed
    if getattr(args, "rule_result", None):
        return read_json(Path(args.rule_result))
    default = task_dir / "run_outputs" / "reward.json"
    return read_json(default) if default.is_file() else None


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    task_dir, outputs_dir, reference_dir = _paths(args)
    instruction, checks, artifacts, references = load_task_inputs(
        task_dir,
        outputs_dir,
        reference_dir,
        max_files=args.max_files,
        total_chars=args.total_chars,
    )
    client = LLMClient(
        model=args.model,
        base_url=args.base_url,
        api_key_env=args.api_key_env,
        temperature=0.0,
        max_tokens=8000,
    )
    runner = JudgeRunner(client)
    task_id = task_dir.name

    if args.command in {"generate-rubric", "run"}:
        rubric = runner.generate_rubric(
            task_id=task_id,
            instruction=instruction,
            objective_checks=checks,
            references=references,
        )
        write_json(Path(args.rubric_out), rubric)
    else:
        rubric = read_json(Path(args.rubric))

    if args.command in {"evaluate", "run"}:
        result = runner.evaluate(
            instruction=instruction,
            rubric=rubric,
            artifacts=artifacts,
            references=references,
            rule_result=_rule_result(args, task_dir),
            judge_runs=args.judge_runs,
            rule_weight=args.rule_weight,
        )
        write_json(Path(args.result_out), result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(json.dumps(rubric, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
