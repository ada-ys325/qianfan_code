from __future__ import annotations

import json
from typing import Any
from .schema import DIMENSIONS

def rubric_messages(instruction: str, checks: dict[str, Any], inventory: list[dict[str, Any]]) -> list[dict[str, str]]:
    return [{"role": "system", "content": "你是静态图片任务的评分标准设计者。只输出 JSON，不要 Markdown。生成候选无关、原子、可定位证据的 criteria。排除文件存在、格式、尺寸等机械检查。每项必须有 id, dimension, description, evidence_hint, weight, levels；levels 必须包含 0 到 4 五个分数锚点。"}, {"role": "user", "content": json.dumps({"instruction": instruction, "objective_checks": checks, "reference_inventory": inventory, "dimensions": DIMENSIONS, "required_schema": {"criteria": "array"}}, ensure_ascii=False)}]

def judge_messages(instruction: str, checks: dict[str, Any], rubric: dict[str, Any], inventory: list[dict[str, Any]]) -> list[dict[str, str]]:
    return [{"role": "system", "content": "你是视觉图片评审员。附件按清单中的 id 和 role 分组，候选在前、参考在后。只根据可见证据评分，不臆测不可见内容；缺失、损坏或未传输证据对应项必须 status=cannot_assess 且 score=null。只输出 JSON，不要 Markdown。每项返回 criterion_id,status(pass/fail/cannot_assess),score(0-4或null),evidence；另含 summary。"}, {"role": "user", "content": json.dumps({"instruction": instruction, "objective_checks": checks, "rubric": rubric, "attachments": inventory}, ensure_ascii=False)}]
