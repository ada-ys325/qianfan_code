from __future__ import annotations

import hashlib
import json
from typing import Any

SCHEMA_VERSION = "1.0"
DIMENSIONS = {
    "instruction_content_fidelity": "指令与内容忠实度",
    "semantic_factual_correctness": "语义与事实正确性",
    "composition_visual_hierarchy": "构图与视觉层级",
    "text_readability": "文字可读性",
    "style_aesthetic_consistency": "风格与美学一致性",
    "reference_fidelity": "参考图忠实度",
    "technical_completeness": "技术完整性",
}

class SchemaError(ValueError):
    pass

def stable_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()

def _text(value: Any, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise SchemaError(f"{name} must be a non-empty string")
    return value.strip()

def normalize_rubric(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise SchemaError("rubric must be an object")
    criteria = raw.get("criteria")
    if not isinstance(criteria, list) or not criteria:
        raise SchemaError("rubric.criteria must be a non-empty array")
    normalized = []
    total = 0.0
    seen = set()
    for i, item in enumerate(criteria):
        if not isinstance(item, dict):
            raise SchemaError(f"criteria[{i}] must be an object")
        cid = _text(item.get("id", f"criterion_{i+1}"), f"criteria[{i}].id")
        if cid in seen:
            raise SchemaError(f"duplicate criterion id: {cid}")
        seen.add(cid)
        dimension = _text(item.get("dimension"), f"{cid}.dimension")
        if dimension not in DIMENSIONS:
            raise SchemaError(f"unsupported dimension: {dimension}")
        try:
            weight = float(item.get("weight"))
        except (TypeError, ValueError) as exc:
            raise SchemaError(f"{cid}.weight must be numeric") from exc
        if weight <= 0:
            raise SchemaError(f"{cid}.weight must be positive")
        levels = item.get("levels")
        if not isinstance(levels, dict) or set(levels) != {"0", "1", "2", "3", "4"}:
            raise SchemaError(f"{cid}.levels must contain string keys 0..4")
        normalized.append({
            "id": cid,
            "dimension": dimension,
            "description": _text(item.get("description"), f"{cid}.description"),
            "evidence_hint": _text(item.get("evidence_hint"), f"{cid}.evidence_hint"),
            "weight": weight,
            "levels": {str(k): _text(v, f"{cid}.levels.{k}") for k, v in levels.items()},
        })
        total += weight
    if total <= 0:
        raise SchemaError("rubric weights must sum to a positive value")
    for item in normalized:
        item["weight"] = round(item["weight"] / total, 8)
    correction = round(1.0 - sum(x["weight"] for x in normalized), 8)
    normalized[-1]["weight"] = round(normalized[-1]["weight"] + correction, 8)
    return {"schema_version": SCHEMA_VERSION, "criteria": normalized}

def validate_rubric(rubric: Any) -> dict[str, Any]:
    normalized = normalize_rubric(rubric)
    if abs(sum(x["weight"] for x in normalized["criteria"]) - 1.0) > 1e-6:
        raise SchemaError("rubric weights must sum to 1")
    return normalized

def validate_judge_result(raw: Any, rubric: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise SchemaError("judge result must be an object")
    items = raw.get("criteria_results")
    if not isinstance(items, list):
        raise SchemaError("criteria_results must be an array")
    expected = {x["id"] for x in rubric["criteria"]}
    actual = {x.get("criterion_id") for x in items if isinstance(x, dict)}
    if actual != expected or len(items) != len(expected):
        raise SchemaError("criteria_results must contain each rubric criterion exactly once")
    total = 0.0
    result = []
    for item in items:
        cid = item.get("criterion_id")
        status = item.get("status")
        if status not in {"pass", "fail", "cannot_assess"}:
            raise SchemaError(f"{cid}.status is invalid")
        score = item.get("score")
        if status == "cannot_assess":
            if score is not None:
                raise SchemaError(f"{cid}.score must be null for cannot_assess")
        elif not isinstance(score, int) or score not in range(5):
            raise SchemaError(f"{cid}.score must be an integer from 0 to 4")
        evidence = item.get("evidence")
        if not isinstance(evidence, str):
            raise SchemaError(f"{cid}.evidence must be a string")
        weight = next(x["weight"] for x in rubric["criteria"] if x["id"] == cid)
        if score is not None:
            total += weight * score
        result.append({"criterion_id": cid, "status": status, "score": score, "evidence": evidence})
    gate = raw.get("gate") or {"status": "ok", "reasons": []}
    if not isinstance(gate, dict) or gate.get("status") not in {"ok", "blocked"} or not isinstance(gate.get("reasons", []), list):
        raise SchemaError("gate must contain status ok/blocked and reasons array")
    return {"schema_version": SCHEMA_VERSION, "criteria_results": result, "weighted_score": round(total, 4), "gate": gate, "summary": str(raw.get("summary", ""))}
