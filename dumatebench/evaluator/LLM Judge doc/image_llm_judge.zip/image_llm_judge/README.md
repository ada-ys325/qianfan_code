# Image LLM-as-a-Judge

`llm_judge_image` 是独立的静态图片 LLM-as-a-Judge，不修改源任务、seed、checks 或历史结果。它先根据任务说明、机械检查摘要和参考图片 inventory 生成候选无关 rubric，再把候选图片和参考图片作为视觉附件交给 OpenAI-compatible JSON 模型。

## 安装

```bash
python -m pip install -r requirements.txt
```

Pillow 和 PyYAML 是必需依赖；`cairosvg` 只用于可选 SVG 内存栅格化。

## 使用

```bash
python -m llm_judge_image.cli generate-rubric \
  --task-dir /path/to/session --reference-dir /path/to/reference \
  --output-dir /tmp/image-judge/rubric --model vision-model

python -m llm_judge_image.cli run \
  --task-dir /path/to/session --candidate-dir /path/to/candidates \
  --reference-dir /path/to/reference --output-dir /tmp/image-judge/result \
  --model vision-model --base-url "$OPENAI_BASE_URL"
```

`run` 输出 `rubric.json`、`judge_result.json` 和 `summary.json`。默认 data URL 模式只将图片放进请求，不将 base64 写进审计 JSON；也可选 `url` 或 `direct_file` 模式。源 session 的输出目录不会被写入。

支持 PNG/JPEG/WEBP。SVG 默认在安装 cairosvg 时栅格化到内存；没有依赖或栅格化失败时会显式记录 `cannot_assess`/blocked gate。Office 内嵌图片不在 v1 范围内。

## 测试

```bash
python -m unittest discover -s tests -v
python -m compileall llm_judge_image tests
```
