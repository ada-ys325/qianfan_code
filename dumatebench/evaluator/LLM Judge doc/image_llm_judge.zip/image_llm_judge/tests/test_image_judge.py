from __future__ import annotations

import io
import json
import subprocess
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image

from llm_judge_image.artifacts import ArtifactError, _safe_path, collect_artifacts, discover_images
from llm_judge_image.checks import summarize_checks
from llm_judge_image.llm import attachment_parts
from llm_judge_image.runner import ImageJudgeRunner
from llm_judge_image.schema import SchemaError, normalize_rubric

RUBRIC = {"criteria": [{"id": "c1", "dimension": "composition_visual_hierarchy", "description": "构图清晰", "evidence_hint": "观察主体和层级", "weight": 2, "levels": {str(i): f"level {i}" for i in range(5)}}, {"id": "c2", "dimension": "text_readability", "description": "文字可读", "evidence_hint": "观察文字", "weight": 1, "levels": {str(i): f"level {i}" for i in range(5)}}]}

class FakeClient:
    def __init__(self): self.calls = []
    def complete_json(self, messages, attachments=None):
        self.calls.append((messages, attachments))
        if attachments is None:
            return RUBRIC
        return {"criteria_results": [{"criterion_id": "c1", "status": "pass", "score": 4, "evidence": "主体清楚"}, {"criterion_id": "c2", "status": "pass", "score": 2, "evidence": "文字可读"}], "summary": "可见证据"}

def image(path: Path, fmt: str = "PNG"):
    Image.new("RGB", (8, 6), (20, 40, 60)).save(path, format=fmt)

class ImageJudgeTests(unittest.TestCase):
    def test_discovery_roles_and_boundary(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); cand = root / "cand"; ref = root / "ref"; cand.mkdir(); ref.mkdir()
            image(cand / "candidate.png"); image(ref / "reference.jpeg", "JPEG")
            items = collect_artifacts(cand, ref)
            self.assertEqual([x["role"] for x in items], ["candidate", "reference"])
            self.assertEqual(items[0]["width"], 8)
            outside = root / "outside.png"; image(outside)
            with self.assertRaises(ArtifactError):
                _safe_path(outside, cand)
            labels = [part["text"] for part in attachment_parts(items) if part["type"] == "text"]
            self.assertEqual(labels, ["[candidate candidate_001]", "[reference reference_001]"])

    def test_corrupt_and_limits(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); image_path = root / "bad.png"; image_path.write_bytes(b"not image")
            item = discover_images(root, "candidate")[0]
            self.assertEqual(item["transport"]["status"], "unavailable")
            self.assertIn("corrupt image", item["transport"]["reason"])
            with self.assertRaises(ArtifactError): discover_images(root, "candidate", max_count=0)
            image_path.unlink(); image(image_path)
            limited = discover_images(root, "candidate", max_bytes=1)[0]
            self.assertEqual(limited["transport"]["status"], "unavailable")

    def test_schema_normalizes_and_rejects(self):
        rubric = normalize_rubric(RUBRIC)
        self.assertAlmostEqual(sum(x["weight"] for x in rubric["criteria"]), 1.0)
        with self.assertRaises(SchemaError): normalize_rubric({"criteria": []})

    def test_end_to_end_no_base64_and_score(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); task = root / "task"; seed = task / "workspace_seed"; cand = root / "cand"; ref = root / "ref"
            seed.mkdir(parents=True); cand.mkdir(); ref.mkdir(); image(cand / "out.webp", "WEBP"); image(ref / "ref.png")
            (task / "instruction.md").write_text("制作图片", encoding="utf-8")
            (task / "evaluator").mkdir(); (task / "evaluator" / "checks.yaml").write_text("checks:\n  - id: exists\n    description: file exists\n", encoding="utf-8")
            client = FakeClient(); runner = ImageJudgeRunner(client)
            result = runner.run(task, cand, ref, root / "output")
            self.assertEqual(result["weighted_score"], 3.3333)
            text = (root / "output" / "judge_result.json").read_text()
            self.assertNotIn("base64", text); self.assertEqual(result["rubric_hash"], json.loads((root / "output" / "rubric.json").read_text())["rubric_hash"])
            self.assertEqual(result["attachments"][0]["role"], "candidate")

    def test_checks_deduplicate_and_gate_corrupt_candidate(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); checks = root / "checks.yaml"
            checks.write_text("checks:\n  - {id: exists, type: evaluate_file_exist, args: {file: out.png}}\n  - {id: duplicate, description: file exists, target: out.png}\n", encoding="utf-8")
            summary = summarize_checks(checks)
            self.assertEqual(summary["target_files"], ["out.png"])
            task = root / "task"; cand = root / "cand"; ref = root / "ref"
            (task / "evaluator").mkdir(parents=True); cand.mkdir(); ref.mkdir()
            (task / "instruction.md").write_text("制作图片", encoding="utf-8")
            (task / "evaluator" / "checks.yaml").write_text("checks: []", encoding="utf-8")
            (cand / "bad.png").write_bytes(b"bad"); image(ref / "ref.png")
            result = ImageJudgeRunner(FakeClient()).run(task, cand, ref, root / "out")
            self.assertEqual(result["gate"]["status"], "blocked")
            self.assertTrue(all(x["status"] == "cannot_assess" for x in result["criteria_results"]))

    def test_missing_reference_only_gates_reference_criterion(self):
        class ReferenceClient:
            def complete_json(self, messages, attachments=None):
                return {"criteria_results": [{"criterion_id": "ref", "status": "pass", "score": 4, "evidence": "claimed"}], "summary": "claimed"}
        rubric = {"criteria": [{"id": "ref", "dimension": "reference_fidelity", "description": "参考忠实", "evidence_hint": "比较参考", "weight": 1, "levels": {str(i): f"level {i}" for i in range(5)}}]}
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); task = root / "task"; cand = root / "cand"
            (task / "evaluator").mkdir(parents=True); cand.mkdir(); image(cand / "out.png")
            (task / "instruction.md").write_text("匹配参考", encoding="utf-8")
            (task / "evaluator" / "checks.yaml").write_text("checks: []", encoding="utf-8")
            result = ImageJudgeRunner(ReferenceClient()).judge(task, cand, None, rubric)
            self.assertEqual(result["gate"]["status"], "blocked")
            self.assertEqual(result["criteria_results"][0]["status"], "cannot_assess")
            self.assertEqual(result["weighted_score"], 0)

    def test_svg_available_and_unavailable(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d); p = root / "x.svg"; p.write_text("<svg xmlns='http://www.w3.org/2000/svg' width='2' height='2'/>", encoding="utf-8")
            with patch.dict("sys.modules", {"cairosvg": None}):
                item = discover_images(root, "candidate")[0]
            self.assertEqual(item["transport"]["status"], "unavailable")
            buf = io.BytesIO(); Image.new("RGB", (2, 2)).save(buf, format="PNG")
            fake = types.SimpleNamespace(svg2png=lambda **kwargs: buf.getvalue())
            with patch.dict("sys.modules", {"cairosvg": fake}):
                item = discover_images(root, "candidate")[0]
            self.assertEqual(item["transport"]["status"], "ready")
            self.assertEqual(item["mime"], "image/png")

    def test_cli_smoke(self):
        proc = subprocess.run([sys.executable, "-m", "llm_judge_image.cli", "--help"], capture_output=True, text=True)
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertIn("generate-rubric", proc.stdout)

if __name__ == "__main__": unittest.main()
