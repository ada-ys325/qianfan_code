# 静态图片 LLM-as-a-Judge 设计与使用报告

## 摘要

本报告对应独立包 `llm_judge_image`。它不改写 `generated_tasks_live/claude-opus-4-8` 的原任务、seed、checks 或历史结果，而是在用户显式指定的输出目录生成 rubric、评分结果和摘要。目标是让视觉模型评价 PNG/JPEG/WEBP 等静态图片的可见质量，同时把机械检查和主观判断边界固定下来。

## 语料快照

当前 149 个 session 的快照中共发现 635 个图片文件，全部位于 `workspace_seed`，尚无 `run_outputs` 图片。按扩展名统计为 PNG 320、JPEG 260、JPG 29、SVG 25、WEBP 1；其中 v1 可直接传输的栅格图片为 610 个，SVG 需可选栅格化。因此本报告只描述图片输入语料的分布与工具能力，不宣称真实候选图片质量，也不伪造在线模型结论。图片主要来自图像生成、海报/封面、信息图、界面或视觉编辑类任务；具体任务的自然语言 instruction 和参考图 inventory 由运行时按 session 读取。Office 文档内嵌图片不纳入 v1。

## 现有 evaluator 的缺口

文字 `llm_judge` 读取文本和结构化产物，适合检查内容、字段、结构和可解析性，但无法直接看到 PNG/JPEG 的视觉证据。`multimodal_llm_judge` 面向音频/视频，rubric 中的时间戳、音画同步、时长等规则不适用于静态图片。新的包只在当前 session 内去重 checks，排除“文件存在、格式有效、尺寸正确”等客观项，防止 LLM 对同一事实重复奖励。

## 设计原则

1. 客观检查负责文件存在、可解析性、MIME、字节大小、尺寸和传输状态。
2. 视觉模型负责可见语义、内容忠实度、构图层级、文字可读性、风格和参考图比较。
3. rubric 先生成、严格归一化和哈希，再冻结给 judge；每个 criterion 是原子且有证据提示。
4. 候选与参考附件按角色显式编号；审计 JSON 只存元数据、哈希和传输状态，不存 base64。
5. 缺图、损坏图或不可传输附件不被静默跳过，而是触发 `cannot_assess` 和 blocked gate。

## 图片 rubric 与分数锚点

默认覆盖七个维度：指令与内容忠实度、语义/事实正确性、构图与视觉层级、文字可读性、风格/美学一致性、参考图忠实度、技术完整性。每一项使用 0 到 4 分：0 表示完全不满足或有致命缺陷，1 表示严重缺失，2 表示部分满足且有明显问题，3 表示基本满足且问题轻微，4 表示充分满足且证据清楚。各项目权重归一化为 1；`cannot_assess` 不臆测分数并由 gate 标明原因。

## 端到端数据流

`instruction.md`、`task.yaml`、`evaluator/checks.yaml` -> checks 摘要与目标文件 -> 参考图片 inventory -> rubric JSON -> rubric hash -> 候选/参考安全采集 -> 图片附件请求 -> judge JSON schema 校验 -> 缺失/不可传输 gate -> 加权总分 -> `rubric.json`、`judge_result.json`、`summary.json`。

示例结果结构：

```json
{
  "rubric_hash": "sha256...",
  "criteria_results": [
    {"criterion_id": "composition", "status": "pass", "score": 3, "evidence": "主体位于画面中心"}
  ],
  "weighted_score": 3.0,
  "gate": {"status": "ok", "reasons": []},
  "attachments": [{"id": "candidate_001", "role": "candidate", "mime": "image/png", "bytes": 1234, "width": 512, "height": 512, "sha256": "...", "transport": {"status": "ready"}}]
}
```

## 使用与验证

```bash
cd /mnt/cfs_algo_bj/workspace/sijinhua/benchmark/image_llm_judge
python -m unittest discover -s tests -v
python -m compileall llm_judge_image tests
python -m llm_judge_image.cli run --task-dir SESSION --candidate-dir CANDIDATES --reference-dir REFERENCES --output-dir /tmp/image-judge
```

测试使用 Pillow 合成 PNG/JPEG/WEBP 和 fake JSON client，不调用真实 API；验证 rubric hash 可复现、权重计算、附件角色顺序、路径边界、损坏图、大小/数量限制、传输 gate 和无 base64 审计输出。配置视觉模型后可额外执行 live smoke；未配置 API 时不能把 fake-client 结果称为真实模型评测。

## 审计与安全措施

使用 `Path.resolve()` 确认图片位于指定根目录；限制单图、总附件数量和字节数；忽略 judge 自身输出；每张图只读取一次用于哈希、元数据和请求；记录 MIME、尺寸、模式、字节数、SHA-256、来源角色和传输状态。URL、data URL、direct-file 三种传输模式由 CLI 显式选择。模型请求可能含图片内容，但落盘 JSON 不含 base64。

## 限制

当前快照没有真实 `run_outputs`，无法对候选生成质量、模型排名一致性或真实视觉模型性能做结论。Office 内嵌图像不纳入 v1；SVG 只有安装 `cairosvg` 时才在内存栅格化，否则明确不可传输。参考图并不自动代表唯一正确答案，模型仍需依据 instruction 和可见证据评分。
